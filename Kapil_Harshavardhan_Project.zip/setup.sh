cd backend
npm install
cd ..
pip install -r requirements.txt